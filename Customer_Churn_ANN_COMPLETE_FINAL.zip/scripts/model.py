from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout

def build_ann(input_shape):
    model = Sequential([
        Dense(64,activation='relu',input_shape=(input_shape,)),
        Dropout(0.2),
        Dense(32,activation='relu'),
        Dense(1,activation='sigmoid')
    ])

    model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])
    return model
