# Customer Churn Prediction using ANN

## Overview
End-to-end ANN project predicting customer churn.

## Structure
- data/
- notebooks/
- scripts/
- requirements.txt

## Results
Accuracy: ~80-85%

## Instructions
1. Add dataset in data/
2. Run notebook
